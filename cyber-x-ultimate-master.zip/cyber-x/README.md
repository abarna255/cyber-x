# CYBER-X — Adversarially Robust Malware Classification

A plain-local frontend and FastAPI backend prototype for safe, static Windows PE analysis. The frontend is a polished cybersecurity dashboard; the backend validates uploads, calculates SHA-256 hashes, extracts the shared ten-feature schema, stores scan history in memory, and exposes controlled adversarial feature-space experiments.

## Project structure

- `src/` — React/Vite dashboard
- `backend/app/` — FastAPI API, schemas, static analysis, history, and adversarial services
- `backend/models/` — reserved for compatible Random Forest artifacts
- `backend/datasets/` — reserved for EMBER setup/data
- `backend/tests/` — backend test location

## Run the frontend

```bash
npm install
npm run dev -- --host 0.0.0.0 --port 5173
```

## Run the backend

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Backend API docs: `http://127.0.0.1:8000/docs`

## Prototype limitations

The backend is intentionally honest about model availability. Without a trained, schema-compatible Random Forest artifact and EMBER training data, `/api/model/status`, `/api/model/metrics`, and scan predictions report unavailable/not evaluated. No malware is executed, and feature-space perturbations are clearly labeled as simulations rather than validated binary evasion attacks.
