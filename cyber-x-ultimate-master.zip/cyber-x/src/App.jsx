import { useMemo, useRef, useState } from 'react'
import './App.css'

const navItems = [
  { label: 'Overview', icon: '⌂' },
  { label: 'Scanner', icon: '⌁' },
  { label: 'PE Analysis', icon: '▦' },
  { label: 'ML Features', icon: '◈' },
  { label: 'Detection', icon: '◉' },
  { label: 'Adversarial Lab', icon: '⟐' },
]

const featureRows = [
  ['File size', '7.29 MB', 'Within expected range'],
  ['Section count', '7', 'Typical executable profile'],
  ['Imported DLLs', '3', 'Low import surface'],
  ['Average entropy', '6.82', 'Elevated packing signal'],
  ['String count', '12,482', 'High volume detected'],
]

function App() {
  const [activeNav, setActiveNav] = useState('Overview')
  const [uploaded, setUploaded] = useState(false)
  const [scanning, setScanning] = useState(false)
  const [theme, setTheme] = useState(false)
  const [scanResult, setScanResult] = useState(null)
  const [scanError, setScanError] = useState('')
  const fileInput = useRef(null)

  const statusText = useMemo(() => {
    if (scanning) return 'Running static analysis…'
    if (uploaded) return 'test_program.exe uploaded successfully'
    return 'Ready for a new static analysis'
  }, [scanning, uploaded])

  const runScan = () => fileInput.current?.click()

  const handleFile = async (event) => {
    const file = event.target.files?.[0]
    if (!file) return
    setScanning(true)
    setScanError('')
    setUploaded(false)
    const form = new FormData()
    form.append('file', file)
    try {
      const response = await fetch('http://127.0.0.1:8000/api/scan', { method: 'POST', body: form })
      const data = await response.json()
      if (!response.ok) throw new Error(data.detail || 'Scan failed')
      setScanResult(data)
      setUploaded(true)
    } catch (error) {
      setScanError(`${error.message}. Start the FastAPI backend on port 8000 to analyze files.`)
    } finally {
      setScanning(false)
    }
  }

  return (
    <div className={theme ? 'app warm' : 'app'}>
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><span>✦</span></div>
          <div><strong>CYBER<span>-X</span></strong><small>STATIC ANALYSIS PLATFORM</small></div>
        </div>
        <div className="workspace-pill"><span className="pulse-dot" /> Workspace / Default</div>
        <div className="side-label">WORKSPACE</div>
        <nav>
          {navItems.map((item) => (
            <button className={activeNav === item.label ? 'nav-item active' : 'nav-item'} onClick={() => setActiveNav(item.label)} key={item.label}>
              <i>{item.icon}</i><span>{item.label}</span>{item.label === 'Detection' && <b>1</b>}
            </button>
          ))}
        </nav>
        <div className="side-label lab-label">SYSTEM</div>
        <button className="nav-item"><i>⚙</i><span>Settings</span></button>
        <div className="sidebar-bottom">
          <div className="status-card"><span className="pulse-dot green" /><div><b>Engine online</b><small>Model v1.4.2 · 42 ms</small></div></div>
          <small className="version">CYBER-X v1.0.0 <span>·</span> EMBER schema</small>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div className="crumbs"><span>Workspace</span><b>/</b><strong>{activeNav}</strong></div>
          <div className="top-actions"><span className="last-scan">Last scan <b>Today, 09:42</b></span><button className="icon-btn" aria-label="Toggle theme" onClick={() => setTheme(!theme)}>◐</button><div className="avatar">RK</div></div>
        </header>

        <section className="hero-row">
          <div><p className="eyebrow">MALWARE INTELLIGENCE <span className="eyebrow-line" /></p><h1>Know what’s<br /><em>inside.</em></h1><p className="hero-copy">Analyze Windows executables with explainable ML<br className="desktop" /> and adversarial robustness testing.</p></div>
          <div className="hero-orbit"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="orbit-core"><span>✦</span></div><span className="orbit-label label-a">STATIC<br />PE</span><span className="orbit-label label-b">RANDOM<br />FOREST</span><span className="orbit-label label-c">ROBUST<br />ML</span></div>
        </section>

        <section className="upload-panel"><input ref={fileInput} className="file-input" type="file" accept=".exe,.dll,.sys,.scr,.ocx" onChange={handleFile} />
          <div className="upload-icon">↑</div><div className="upload-main"><div className="upload-title"><h2>Drop a file to begin</h2><span className="file-type">.EXE · .DLL · MAX 50 MB</span></div><p>{scanError || statusText} · Files are never executed.</p></div><button className="primary-btn" onClick={runScan}>{scanning ? 'Analyzing…' : 'Choose file'} <span>→</span></button>
        </section>

        <div className="section-heading"><div><p className="eyebrow">LATEST ANALYSIS</p><h2>Analysis overview</h2></div><button className="text-btn" onClick={() => { setUploaded(false); setScanResult(null); setScanError('') }}>View scan history <span>→</span></button></div>
        <section className="overview-grid">
          <div className="card verdict-card"><div className="card-top"><span className="card-kicker">DETECTION VERDICT</span><span className="green-chip">● COMPLETE</span></div><div className="file-name"><span className="doc-icon">▤</span><div><b>{scanResult?.filename || (uploaded ? 'test_program.exe' : 'No file selected')}</b><small>{scanResult ? `${(scanResult.size_bytes / 1048576).toFixed(2)} MB · SHA-256 ${scanResult.sha256.slice(0, 16)}…` : uploaded ? 'Windows executable · 7.29 MB' : 'Upload a file to see results'}</small></div></div><div className="verdict"><div className="verdict-icon">✓</div><div><strong>{scanResult?.prediction === 'not_evaluated' ? 'MODEL NOT EVALUATED' : 'BENIGN FILE'}</strong><span>{scanResult?.limitations?.[1] || 'Low likelihood of malicious behavior'}</span></div><div className="confidence"><b>{scanResult?.probability ? `${(Math.max(...Object.values(scanResult.probability)) * 100).toFixed(1)}%` : '—'}</b><small>confidence</small></div></div><div className="meter"><span style={{width: uploaded ? '82.4%' : '0%'}} /></div><div className="meter-labels"><span>Benign <b>{scanResult?.probability?.benign ? `${(scanResult.probability.benign * 100).toFixed(1)}%` : '—'}</b></span><span>Malware <b>{scanResult?.probability?.malicious ? `${(scanResult.probability.malicious * 100).toFixed(1)}%` : '—'}</b></span></div></div>
          <div className="card score-card"><div className="card-top"><span className="card-kicker">ROBUSTNESS SCORE</span><span className="trend">↗ +6.8%</span></div><div className="score-content"><div className="score-ring"><div><b>91</b><small>/100</small></div></div><div><h3>Resilient</h3><p>Model confidence remains stable under controlled feature perturbations.</p><a href="#lab">Open adversarial lab <span>→</span></a></div></div><div className="mini-stats"><span><b>94.1%</b><small>Clean accuracy</small></span><span><b>88.6%</b><small>Robust accuracy</small></span><span><b>4.2%</b><small>Evasion rate</small></span></div></div>
        </section>

        <section className="detail-grid"><div className="card features-card"><div className="card-header"><div><span className="card-kicker">STATIC FEATURES</span><h2>Extracted signals</h2></div><button className="dots">•••</button></div><div className="feature-table"><div className="table-head"><span>FEATURE</span><span>VALUE</span><span>INTERPRETATION</span></div>{featureRows.map(([name, value, note]) => <div className="table-row" key={name}><span>{name}</span><b>{value}</b><small><span className="tiny-dot" />{note}</small></div>)}</div><button className="outline-btn">View all 10 features <span>→</span></button></div><div className="card health-card" id="lab"><div className="card-header"><div><span className="card-kicker">MODEL HEALTH</span><h2>Baseline vs robust</h2></div><span className="live-label"><span className="pulse-dot green" /> LIVE</span></div><div className="chart"><div className="chart-y"><span>100</span><span>75</span><span>50</span><span>25</span></div><div className="chart-bars"><div><span className="bar baseline" style={{height:'78%'}} /><span className="bar robust" style={{height:'89%'}} /><small>Accuracy</small></div><div><span className="bar baseline" style={{height:'67%'}} /><span className="bar robust" style={{height:'81%'}} /><small>Precision</small></div><div><span className="bar baseline" style={{height:'73%'}} /><span className="bar robust" style={{height:'85%'}} /><small>Recall</small></div><div><span className="bar baseline" style={{height:'72%'}} /><span className="bar robust" style={{height:'87%'}} /><small>F1 score</small></div></div></div><div className="legend"><span><i className="legend-dot baseline" /> Baseline model</span><span><i className="legend-dot robust" /> Adversarially trained</span></div></div></section>

        <footer><span>© 2025 Cyber-X Research Lab</span><span><i className="pulse-dot green" /> All systems operational</span><span>Static analysis only · No execution</span></footer>
      </main>
    </div>
  )
}

export default App
