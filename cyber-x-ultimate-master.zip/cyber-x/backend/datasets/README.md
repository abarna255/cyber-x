# EMBER dataset setup

Place the EMBER release files here only after verifying the license and source. The final model training pipeline should document dataset version, label validation, duplicate checks, train/validation/test separation, random seed, and the exact ten-feature schema. The prototype does not bundle EMBER or claim trained performance.
