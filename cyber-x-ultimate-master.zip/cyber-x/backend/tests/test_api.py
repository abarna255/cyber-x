from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    response = client.get('/api/health')
    assert response.status_code == 200
    assert response.json()['static_analysis'] == 'available'

def test_rejects_unsupported_extension():
    response = client.post('/api/scan', files={'file': ('sample.txt', b'hello', 'text/plain')})
    assert response.status_code == 415
