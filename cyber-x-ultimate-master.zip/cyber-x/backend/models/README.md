# Model artifacts

Store only schema-compatible, locally trained artifacts here. A production implementation should save the Random Forest model together with the feature order, preprocessing configuration, threshold, dataset metadata, and model version. The current prototype reports model availability as unavailable until such an artifact is supplied.
