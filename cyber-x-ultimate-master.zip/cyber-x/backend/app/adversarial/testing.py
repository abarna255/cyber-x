import random
from app.ml.model import model_service

def run_test(features: dict, strength: float, trials: int, seed: int) -> dict:
    rng = random.Random(seed)
    numeric = ['average_entropy', 'maximum_entropy', 'string_count', 'imported_function_count']
    perturbations = []
    for _ in range(min(trials, 20)):
        key = rng.choice(numeric)
        delta = round(rng.uniform(-strength, strength) * max(1, float(features[key])), 4)
        perturbations.append({'feature': key, 'delta': delta, 'seed': seed})
    baseline, _ = model_service.predict(features)
    return {
        'baseline_prediction': baseline,
        'perturbed_prediction': 'not_evaluated',
        'changed': False,
        'trials': trials,
        'evasion_success_rate': None,
        'perturbations': perturbations,
        'limitation': 'Feature-space perturbations are simulated experiments, not validated binary modifications. A trained model is required for measured predictions.',
    }
