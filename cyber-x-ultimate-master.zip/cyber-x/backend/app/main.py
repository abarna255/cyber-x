import hashlib
import uuid
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.adversarial.testing import run_test
from app.analysis.pe_features import extract_features
from app.core.config import ALLOWED_EXTENSIONS, MAX_UPLOAD_BYTES, MODEL_VERSION
from app.database.history import delete, get, list_all, save
from app.ml.model import model_service
from app.schemas.api import AdversarialTestRequest, AdversarialTestResult, HealthResponse, ScanResult

app = FastAPI(title='CYBER-X API', version='0.1.0', description='Static PE analysis and adversarial robustness prototype')
app.add_middleware(CORSMiddleware, allow_origins=['http://localhost:5173', 'http://127.0.0.1:5173'], allow_credentials=True, allow_methods=['*'], allow_headers=['*'])

@app.get('/api/health', response_model=HealthResponse)
def health():
    return HealthResponse(status='ok', static_analysis='available', model='unavailable', message='Static inspection is enabled. No trained model artifact is bundled.')

@app.get('/api/model/status')
def model_status():
    return model_service.status()

@app.get('/api/model/metrics')
def model_metrics():
    return {'status': 'not_evaluated', 'metrics': {'accuracy': None, 'precision': None, 'recall': None, 'f1_score': None, 'roc_auc': None}, 'message': 'Train a compatible model with the EMBER setup before displaying measured metrics.'}

@app.get('/api/model/comparison')
def model_comparison():
    return {'status': 'not_evaluated', 'baseline': None, 'adversarially_trained': None, 'message': 'Comparison requires clean and adversarial test results.'}

@app.post('/api/scan', response_model=ScanResult)
async def scan(file: UploadFile = File(...)):
    suffix = Path(file.filename or '').suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=415, detail='Unsupported file type. Upload a Windows PE file such as .exe or .dll.')
    data = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail='File exceeds the 50 MB upload limit.')
    if not data:
        raise HTTPException(status_code=400, detail='Uploaded file is empty.')
    digest = hashlib.sha256(data).hexdigest()
    features, indicators, extractor = extract_features(data)
    prediction, probability = model_service.predict(features)
    limitations = ['Uploaded data is inspected statically and never executed.', 'Prediction is not evaluated until a compatible trained Random Forest artifact is supplied.']
    record = {'scan_id': uuid.uuid4().hex, 'filename': file.filename or 'unknown', 'sha256': digest, 'size_bytes': len(data), 'file_type': extractor, 'prediction': prediction, 'probability': probability, 'model_status': MODEL_VERSION, 'features': features, 'indicators': indicators, 'limitations': limitations, 'created_at': datetime.now(timezone.utc).isoformat()}
    return save(record)

@app.get('/api/scans')
def scans():
    return {'items': list_all(), 'count': len(list_all())}

@app.get('/api/scan/{scan_id}', response_model=ScanResult)
def scan_by_id(scan_id: str):
    item = get(scan_id)
    if not item:
        raise HTTPException(status_code=404, detail='Scan not found.')
    return item

@app.delete('/api/scan/{scan_id}')
def delete_scan(scan_id: str):
    if not delete(scan_id):
        raise HTTPException(status_code=404, detail='Scan not found.')
    return {'deleted': True, 'scan_id': scan_id}

@app.post('/api/adversarial/test', response_model=AdversarialTestResult)
def adversarial_test(request: AdversarialTestRequest):
    return run_test(request.features.model_dump(), request.strength, request.trials, request.seed)

@app.exception_handler(Exception)
async def safe_errors(_, exc):
    return JSONResponse(status_code=500, content={'detail': 'Unexpected backend error. Check server logs for diagnostics.'})
