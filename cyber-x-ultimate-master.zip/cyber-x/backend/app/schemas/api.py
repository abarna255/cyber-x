from typing import Any
from pydantic import BaseModel, Field

class HealthResponse(BaseModel):
    status: str
    static_analysis: str
    model: str
    message: str

class FeatureVector(BaseModel):
    file_size: int = Field(ge=0)
    section_count: int = Field(ge=0)
    imported_dll_count: int = Field(ge=0)
    imported_function_count: int = Field(ge=0)
    export_count: int = Field(ge=0)
    average_entropy: float = Field(ge=0)
    maximum_entropy: float = Field(ge=0)
    string_count: int = Field(ge=0)
    average_string_length: float = Field(ge=0)
    digital_signature_flag: int = Field(ge=0, le=1)

class ScanResult(BaseModel):
    scan_id: str
    filename: str
    sha256: str
    size_bytes: int
    file_type: str
    prediction: str
    probability: dict[str, float] | None
    model_status: str
    features: FeatureVector
    indicators: list[str]
    limitations: list[str]
    created_at: str

class AdversarialTestRequest(BaseModel):
    features: FeatureVector
    strength: float = Field(default=0.1, gt=0, le=0.5)
    trials: int = Field(default=20, ge=1, le=500)
    seed: int = 42

class AdversarialTestResult(BaseModel):
    baseline_prediction: str
    perturbed_prediction: str
    changed: bool
    trials: int
    evasion_success_rate: float | None
    perturbations: list[dict[str, Any]]
    limitation: str
