from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
MAX_UPLOAD_BYTES = 50 * 1024 * 1024
ALLOWED_EXTENSIONS = {'.exe', '.dll', '.sys', '.scr', '.ocx'}
FEATURE_SCHEMA = [
    'file_size', 'section_count', 'imported_dll_count',
    'imported_function_count', 'export_count', 'average_entropy',
    'maximum_entropy', 'string_count', 'average_string_length',
    'digital_signature_flag',
]
MODEL_VERSION = 'prototype-untrained-v0.1'
