from typing import Any

_records: dict[str, dict[str, Any]] = {}

def save(record: dict[str, Any]) -> dict[str, Any]:
    _records[record['scan_id']] = record
    return record

def get(scan_id: str):
    return _records.get(scan_id)

def list_all():
    return list(reversed(list(_records.values())))

def delete(scan_id: str) -> bool:
    return _records.pop(scan_id, None) is not None
