from dataclasses import dataclass

@dataclass
class ModelService:
    version: str = 'prototype-untrained-v0.1'
    trained: bool = False

    def status(self) -> dict:
        return {
            'available': self.trained,
            'type': 'RandomForestClassifier',
            'version': self.version,
            'dataset': 'EMBER (not bundled; setup required)',
            'message': 'No trained model artifact is bundled. Upload analysis remains static-only until a compatible model is trained.',
        }

    def predict(self, features: dict) -> tuple[str, dict[str, float] | None]:
        # Explicitly unavailable rather than fabricating a learned result.
        return 'not_evaluated', None

model_service = ModelService()
