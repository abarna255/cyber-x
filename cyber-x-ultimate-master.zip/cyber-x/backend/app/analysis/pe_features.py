import math
import re
from collections import Counter


def _entropy(data: bytes) -> float:
    if not data:
        return 0.0
    counts = Counter(data)
    length = len(data)
    return -sum((n / length) * math.log2(n / length) for n in counts.values())


def extract_features(data: bytes) -> tuple[dict, list[str], str]:
    """Static-only extractor. Uses PE headers when present and safe byte heuristics otherwise."""
    is_pe = data[:2] == b'MZ' and b'PE\x00\x00' in data[:4096]
    strings = re.findall(rb'[ -~]{4,}', data)
    sample = data[: min(len(data), 2_000_000)]
    entropy = _entropy(sample)
    features = {
        'file_size': len(data),
        'section_count': max(0, data[0x06] if is_pe and len(data) > 0x06 else 0),
        'imported_dll_count': len(re.findall(rb'(?i)[a-z0-9_\-]{2,32}\.(?:dll|sys)', data)),
        'imported_function_count': len(re.findall(rb'(?i)\b(?:Create|Get|Load|Virtual|Write|Open|Reg)[A-Za-z0-9_]{2,48}\b', data)),
        'export_count': len(re.findall(rb'(?i)\bDllMain\b|\bEXPORTS\b', data)),
        'average_entropy': round(entropy, 4),
        'maximum_entropy': round(entropy, 4),
        'string_count': len(strings),
        'average_string_length': round(sum(len(s) for s in strings) / len(strings), 4) if strings else 0.0,
        'digital_signature_flag': 1 if b'Authenticode' in data or b'WIN_CERTIFICATE' in data else 0,
    }
    indicators = []
    if not is_pe:
        indicators.append('File does not contain a complete PE signature; metadata coverage is limited.')
    if entropy >= 7.2:
        indicators.append('High byte entropy may indicate packing or compression.')
    if features['imported_dll_count'] >= 10:
        indicators.append('Large imported library surface detected.')
    if any(token in data.lower() for token in (b'urlmon', b'wininet', b'powershell', b'cmd.exe')):
        indicators.append('Network or command execution related strings detected.')
    return features, indicators, 'pe-header-and-static-byte-heuristics'
