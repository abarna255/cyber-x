# CYBER-X FastAPI backend prototype

This backend provides a safe static-analysis API for the CYBER-X frontend.

## Run locally

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Open API docs at `http://127.0.0.1:8000/docs`.

## Implemented endpoints

- `GET /api/health`
- `GET /api/model/status`
- `GET /api/model/metrics`
- `GET /api/model/comparison`
- `POST /api/scan`
- `GET /api/scans`
- `GET /api/scan/{scan_id}`
- `DELETE /api/scan/{scan_id}`
- `POST /api/adversarial/test`

## Important project status

This is a functional backend prototype. It hashes uploads, validates extensions and size, extracts static byte/PE signals, records scan history in memory, and exposes controlled feature-space adversarial experiments. It intentionally reports `not_evaluated` when no compatible trained Random Forest artifact is available; it does not fabricate malware predictions or metrics.

To activate measured ML results, add a reproducible training pipeline and model artifact under `models/` using the documented ten-feature schema and EMBER data split. Uploaded files are never executed.
