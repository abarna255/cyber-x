#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"

if [ ! -d "$ROOT/backend/.venv" ]; then
  python3 -m venv "$ROOT/backend/.venv"
  "$ROOT/backend/.venv/bin/pip" install -r "$ROOT/backend/requirements.txt"
fi

trap 'kill 0' INT TERM EXIT
(
  cd "$ROOT/backend"
  PYTHONPATH=. "$ROOT/backend/.venv/bin/uvicorn" app.main:app --reload --host 127.0.0.1 --port 8000
) &
(
  cd "$ROOT"
  npm install
  npm run dev -- --host 127.0.0.1 --port 5173
) &
wait
