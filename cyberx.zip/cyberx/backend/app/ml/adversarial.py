"""FEATURE-SPACE perturbations only. These are simulations, NOT validated binary-level evasion."""
import numpy as np
from .schema import FEATURES, BOUNDS
# Features an attacker could plausibly shift by appending/padding data, and the direction:
DIRECTIONS = {"file_size": +1, "string_count": +1, "avg_entropy": -1, "max_entropy": -1,
              "imported_function_count": +1, "section_count": +1}

def perturb(X, strength=0.2, features=None, seed=0):
    """Shift each chosen feature by a random fraction in [0, strength] of its value, then clip to BOUNDS."""
    rng = np.random.default_rng(seed)
    Xp = np.array(X, dtype=float).copy()
    for name in (features or list(DIRECTIONS)):
        j = FEATURES.index(name)
        Xp[:, j] *= 1 + DIRECTIONS[name] * rng.uniform(0, strength, len(Xp))
        lo, hi = BOUNDS[name]; Xp[:, j] = np.clip(Xp[:, j], lo, hi)
        if name in ("file_size","section_count","string_count","imported_function_count"):
            Xp[:, j] = np.round(Xp[:, j])   # count features stay integers
    return Xp

def evasion_success_rate(model, X, y, strength=0.2, features=None, seed=0):
    """Among malware samples the model catches on clean input, share that flip to benign after perturbation."""
    X, y = np.asarray(X), np.asarray(y)
    mal = X[(y == 1) & (model.predict(X) == 1)]
    if len(mal) == 0: return None            # nothing to evaluate -> "Not evaluated"
    return float((model.predict(perturb(mal, strength, features, seed)) == 0).mean())
