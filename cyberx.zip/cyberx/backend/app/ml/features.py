"""Static feature extraction. The file is only read as bytes and parsed, never executed."""
import math, re, hashlib
from collections import Counter
from .schema import FEATURES, validate_vector

def entropy(data: bytes) -> float:
    if not data: return 0.0
    n = len(data)
    return -sum(c / n * math.log2(c / n) for c in Counter(data).values())

STRING_RE = re.compile(rb"[\x20-\x7e]{5,}")   # rule: printable ASCII runs of >= 5 chars

def extract_features(path: str) -> dict:
    import pefile  # imported lazily so the rest of the package works without it
    raw = open(path, "rb").read()
    pe = pefile.PE(data=raw, fast_load=False)   # raises PEFormatError for non-PE input
    sec_ent = [entropy(s.get_data()) for s in pe.sections] or [0.0]
    imports = getattr(pe, "DIRECTORY_ENTRY_IMPORT", [])
    exports = getattr(getattr(pe, "DIRECTORY_ENTRY_EXPORT", None), "symbols", [])
    strings = STRING_RE.findall(raw)
    sig = pe.OPTIONAL_HEADER.DATA_DIRECTORY[4]   # index 4 = certificate table
    feats = {"file_size": len(raw), "section_count": len(pe.sections),
             "imported_dll_count": len(imports),
             "imported_function_count": sum(len(i.imports) for i in imports),
             "export_count": len(exports), "avg_entropy": sum(sec_ent) / len(sec_ent),
             "max_entropy": max(sec_ent), "string_count": len(strings),
             "avg_string_length": (sum(map(len, strings)) / len(strings)) if strings else 0.0,
             "has_signature": int(sig.Size > 0)}
    validate_vector([feats[f] for f in FEATURES])
    return {"sha256": hashlib.sha256(raw).hexdigest(), "features": feats}
