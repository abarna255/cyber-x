"""Baseline + adversarial training. Input: CSV with the ten FEATURES columns and a 'label' column (0 benign, 1 malware)."""
import json, sys, time, joblib, numpy as np, pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
from .schema import FEATURES, SCHEMA_VERSION
from .adversarial import perturb, evasion_success_rate
CFG = dict(n_estimators=200, max_depth=None, min_samples_split=2, min_samples_leaf=1, class_weight="balanced", seed=42, strength=0.2)

def load(csv):
    df = pd.read_csv(csv)
    missing = set(FEATURES + ["label"]) - set(df.columns)
    if missing: raise ValueError(f"CSV missing columns: {sorted(missing)}")
    df = df.drop_duplicates()
    if not set(df.label.unique()) <= {0, 1}: raise ValueError("labels must be 0/1")
    return df[FEATURES].to_numpy(float), df.label.to_numpy(int)

def rf(c): return RandomForestClassifier(n_estimators=c["n_estimators"], max_depth=c["max_depth"],
        min_samples_split=c["min_samples_split"], min_samples_leaf=c["min_samples_leaf"],
        class_weight=c["class_weight"], random_state=c["seed"], n_jobs=-1)

def metrics(m, X, y):
    t = time.perf_counter(); p = m.predict(X); ms = (time.perf_counter() - t) / len(X) * 1000
    tn, fp, fn, tp = confusion_matrix(y, p, labels=[0, 1]).ravel()
    return dict(accuracy=accuracy_score(y, p), precision=precision_score(y, p, zero_division=0),
                recall=recall_score(y, p, zero_division=0), f1=f1_score(y, p, zero_division=0),
                fpr=fp / max(fp + tn, 1), fnr=fn / max(fn + tp, 1), roc_auc=roc_auc_score(y, m.predict_proba(X)[:, 1]),
                confusion_matrix=[[int(tn), int(fp)], [int(fn), int(tp)]], latency_ms_per_sample=ms)

def run(csv, out="models", cfg=CFG):
    X, y = load(csv)
    # Test set is split off first and never used for tuning or adversarial-training decisions.
    Xtv, Xte, ytv, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=cfg["seed"])
    Xtr, Xva, ytr, yva = train_test_split(Xtv, ytv, test_size=0.25, stratify=ytv, random_state=cfg["seed"])
    base = rf(cfg).fit(Xtr, ytr)
    # Adversarial training: add perturbed copies of TRAINING malware only (labels stay 1).
    Xadv = perturb(Xtr[ytr == 1], cfg["strength"], seed=cfg["seed"])
    robust = rf(cfg).fit(np.vstack([Xtr, Xadv]), np.concatenate([ytr, np.ones(len(Xadv), int)]))
    Xte_adv = perturb(Xte, cfg["strength"], seed=cfg["seed"] + 1)   # different seed than training perturbations
    res = {}
    for name, m in [("baseline", base), ("robust", robust)]:
        res[name] = dict(clean=metrics(m, Xte, yte), validation_accuracy=accuracy_score(yva, m.predict(Xva)),
            robust_accuracy=accuracy_score(yte, m.predict(Xte_adv)),
            evasion_success_rate=evasion_success_rate(m, Xte, yte, cfg["strength"], seed=cfg["seed"] + 1))
    res["config"] = dict(cfg, schema=SCHEMA_VERSION, features=FEATURES, dataset=str(csv), n_train=len(Xtr), n_test=len(Xte),
        evaluation="feature-space simulation, not binary-level", trained_at=time.strftime("%Y-%m-%d %H:%M:%S"))
    import os; os.makedirs(out, exist_ok=True)
    for name, m in [("baseline", base), ("robust", robust)]:
        joblib.dump({"model": m, "features": FEATURES, "schema": SCHEMA_VERSION, "version": f"{name}-{res['config']['trained_at']}"}, f"{out}/{name}.joblib")
    json.dump(res, open(f"{out}/metrics.json", "w"), indent=2, default=float)
    return res

if __name__ == "__main__":
    run(sys.argv[1])
