"""Single source of truth for the ten model features (same order in training and inference)."""
FEATURES = ["file_size", "section_count", "imported_dll_count", "imported_function_count",
            "export_count", "avg_entropy", "max_entropy", "string_count",
            "avg_string_length", "has_signature"]
# (min, max) valid ranges; entropy is Shannon entropy in bits/byte (0-8)
BOUNDS = {"file_size": (1, 5e8), "section_count": (1, 96), "imported_dll_count": (0, 500),
          "imported_function_count": (0, 20000), "export_count": (0, 20000),
          "avg_entropy": (0, 8), "max_entropy": (0, 8), "string_count": (0, 1e7),
          "avg_string_length": (0, 4096), "has_signature": (0, 1)}
SCHEMA_VERSION = "tenfeat-v1"

def validate_vector(row):
    """Reject wrong length, NaN, or out-of-range values instead of silently fixing them."""
    if len(row) != len(FEATURES): raise ValueError("wrong feature count")
    for name, v in zip(FEATURES, row):
        lo, hi = BOUNDS[name]
        if v != v or not (lo <= v <= hi): raise ValueError(f"invalid value for {name}: {v}")
