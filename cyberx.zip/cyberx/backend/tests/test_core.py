"""Tests use a SYNTHETIC fixture only to exercise code paths. Its numbers say nothing about real malware performance."""
import numpy as np, pandas as pd, pytest, joblib
from app.ml.schema import FEATURES, validate_vector
from app.ml.adversarial import perturb
from app.ml import train

def fixture_csv(tmp_path, n=600):
    rng = np.random.default_rng(1); y = rng.integers(0, 2, n)
    d = {"file_size": rng.uniform(5e4, 5e6, n), "section_count": rng.integers(3, 8, n) + y,
         "imported_dll_count": rng.integers(2, 20, n), "imported_function_count": rng.integers(20, 400, n) - 100 * y,
         "export_count": rng.integers(0, 5, n), "avg_entropy": 5 + 1.5 * y + rng.normal(0, .4, n),
         "max_entropy": 6 + 1.5 * y + rng.normal(0, .3, n), "string_count": rng.integers(100, 3000, n) - 800 * y,
         "avg_string_length": rng.uniform(6, 20, n), "has_signature": (1 - y) * rng.integers(0, 2, n), "label": y}
    p = tmp_path / "f.csv"; df = pd.DataFrame(d); df[FEATURES[:-1]] = df[FEATURES[:-1]].clip(lower=1).round(3); df.to_csv(p, index=False); return p

def test_validate_rejects_bad():
    with pytest.raises(ValueError): validate_vector([1] * 9)
    with pytest.raises(ValueError): validate_vector([100, 3, 1, 1, 0, 9.5, 7, 10, 5, 0])

def test_perturb_bounded_and_reproducible():
    X = np.array([[1e6, 5, 10, 100, 0, 6.0, 7.0, 500, 8.0, 0]])
    a, b = perturb(X, .2, seed=3), perturb(X, .2, seed=3)
    assert (a == b).all() and a[0, 0] >= X[0, 0] and a[0, 5] <= X[0, 5] and a[0, 0] <= X[0, 0] * 1.2 + 1

def test_train_pipeline_and_reload(tmp_path):
    res = train.run(fixture_csv(tmp_path), out=str(tmp_path / "m"))
    assert set(res) >= {"baseline", "robust", "config"}
    art = joblib.load(tmp_path / "m" / "baseline.joblib")
    assert art["features"] == FEATURES and art["model"].n_features_in_ == 10
