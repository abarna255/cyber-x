# CYBER-X — Adversarially Robust Malware Classification (core engine, stage 1)

Implemented: ten-feature schema, static PE feature extraction (pefile), bounded feature-space
adversarial perturbations, baseline + adversarially trained Random Forest, tests.
NOT implemented: FastAPI API, React frontend, SQLite history, reports.

## Setup
    cd backend
    pip install numpy pandas scikit-learn joblib pefile pytest

## Train (needs a CSV with the 10 feature columns in app/ml/schema.py plus a 0/1 `label` column)
    python -m app.ml.train path/to/dataset.csv
Writes models/baseline.joblib, models/robust.joblib, models/metrics.json.

## Test
    python -m pytest -q tests
(tests use a synthetic fixture; their numbers are not real-world results)

## Limitations
Adversarial results are feature-space simulations, not validated binary-level evasion.
Ten-feature model is not equivalent to a full-EMBER-feature model.
